import * as React from "react";

export default function Header() {
  return (
    <div>
      <h1> Bank</h1>
    </div>
  );
}
