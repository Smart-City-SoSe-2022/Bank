import * as React from "react";

export default function Kredit() {
  return (
    <div>
      <h1> Kredit</h1>
    </div>
  );
}
