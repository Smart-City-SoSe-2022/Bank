import * as React from "react";

export default function Transfer() {
  return (
    <div>
      <h1> Überweisung</h1>
    </div>
  );
}
